for img in /home/kalin/programming/frames_ascii/amogus-*.png; do
    jp2a --width=80 --colors "$img" > "/home/kalin/programming/text_amongus/$(basename "$img" .png).txt"
done
